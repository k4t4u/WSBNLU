package kosztorysy;

import sprzet.SprzetBudowlany;
import zlecenia.ZlecenieBudowlane;

public class KosztorysBudowlany {
    private final ZlecenieBudowlane zlecenie;
    private SprzetBudowlany koparka;
    private SprzetBudowlany dzwig;
    private SprzetBudowlany betoniarka;
    private final int dniPracy;

    public KosztorysBudowlany(ZlecenieBudowlane zlecenie, int dniPracy) {
        this.zlecenie = zlecenie;
        this.dniPracy = dniPracy;
    }

    public void DodajKoparke(SprzetBudowlany koparka) {
        this.koparka = koparka;
    }

    public void DodajDzwig(SprzetBudowlany dzwig) {
        this.dzwig = dzwig;
    }

    public void DodajBetoniarke(SprzetBudowlany betoniarka) {
        this.betoniarka = betoniarka;
    }

    public double ObliczKosztSprzetu() {
        double kosztSprzetu = 0.0;
        if (koparka != null) {
            double kosztKoparki = koparka.ObliczKosztEksploatacjiDzienny() * dniPracy;
            kosztSprzetu += kosztKoparki;
        }
        if (dzwig != null) {
            double kosztDzwigu = dzwig.ObliczKosztEksploatacjiDzienny() * dniPracy;
            kosztSprzetu += kosztDzwigu;
        }
        if (betoniarka != null) {
            double kosztBetoniarki = betoniarka.ObliczKosztEksploatacjiDzienny() * dniPracy;
            kosztSprzetu += kosztBetoniarki;
        }
        return kosztSprzetu;
    }

    public double ObliczCalkowityKoszt() {
        double kosztZlecenia = zlecenie.ObliczKosztCalosciZlecenia();
        double kosztSprzetu = ObliczKosztSprzetu();
        return kosztZlecenia + kosztSprzetu;
    }


    public void DrukujKosztorys() {
        System.out.println("Kosztorys zlecenia:");
        zlecenie.DrukujDaneZlecenia();

        System.out.println("Koszt sprzętu (uwzględniając liczbę dni: " + dniPracy + "):");
        if (koparka != null) {
            koparka.DrukujKosztEksploatacji();
            System.out.println("Koszt użycia koparki przez " + dniPracy + " dni: " + (koparka.ObliczKosztEksploatacjiDzienny() * dniPracy) + " zł");
        }
        if (dzwig != null) {
            dzwig.DrukujKosztEksploatacji();
            System.out.println("Koszt użycia dźwigu przez " + dniPracy + " dni: " + (dzwig.ObliczKosztEksploatacjiDzienny() * dniPracy) + " zł");
        }
        if (betoniarka != null) {
            betoniarka.DrukujKosztEksploatacji();
            System.out.println("Koszt użycia betoniarki przez " + dniPracy + " dni: " + (betoniarka.ObliczKosztEksploatacjiDzienny() * dniPracy) + " zł");
        }

        System.out.println("Całkowity koszt zlecenia z uwzględnieniem sprzętu: " + ObliczCalkowityKoszt() + " zł");
    }
}
