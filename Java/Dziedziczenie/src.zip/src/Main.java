import kosztorysy.KosztorysBudowlany;
import parametry.Data;
import pracownicy.PracownikBudowlany;
import sprzet.Betoniarka;
import sprzet.Dzwig;
import sprzet.Koparka;
import zlecenia.ZlecenieNaElewacje;
import zlecenia.ZlecenieNaFundamenty;

public class Main {
    public static void main(String[] args) {

        System.out.println("Zastosowania klas abstrakcyjnych w branży budowlanej\n");

        PracownikBudowlany pracownik = new PracownikBudowlany("Piotr", "Jagodzinski", "Kierownik budowy");

        Data dataZawarcia = new Data(10, 10, 2024);

        ZlecenieNaFundamenty zlecenieFundamenty = new ZlecenieNaFundamenty(
                "FND-001",
                pracownik,
                dataZawarcia,
                "Fundamenty domu",
                160,
                20000.0
        );

        ZlecenieNaElewacje zlecenieElewacje = new ZlecenieNaElewacje(
                "ELEW-001",
                pracownik,
                dataZawarcia,
                "Elewacja domu",
                150,
                5000.0,
                3000.0
        );

        Koparka koparka = new Koparka(8);
        Dzwig dzwig = new Dzwig(10);
        Betoniarka betoniarka = new Betoniarka(6);

        KosztorysBudowlany kosztorysFundamenty = new KosztorysBudowlany(zlecenieFundamenty, 5);
        kosztorysFundamenty.DodajKoparke(koparka);
        kosztorysFundamenty.DodajDzwig(dzwig);
        kosztorysFundamenty.DodajBetoniarke(betoniarka);

        KosztorysBudowlany kosztorysElewacje = new KosztorysBudowlany(zlecenieElewacje, 3);
        kosztorysElewacje.DodajKoparke(koparka);
        kosztorysElewacje.DodajBetoniarke(betoniarka);

        System.out.println("Kosztorys dla fundamentów:");
        kosztorysFundamenty.DrukujKosztorys();
        System.out.println("\n\nKosztorys dla elewacji:");
        kosztorysElewacje.DrukujKosztorys();

        System.out.println("\n\nKoszt zlecenia na fundamenty: " + zlecenieFundamenty.ObliczKosztCalosciZlecenia() + " zł");
        System.out.println("Koszt zlecenia na elewację: " + zlecenieElewacje.ObliczKosztCalosciZlecenia() + " zł");

        System.out.println("\n\nTestowanie metod z klas abstrakcyjnych:");
        zlecenieFundamenty.DrukujKosztZlecenia();
        zlecenieElewacje.DrukujKosztZlecenia();
    }
}