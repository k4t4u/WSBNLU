package parametry;

public class ParametryBudowlane {

    public static double StawkaGodzinowaPracownika() {
        return 50.0;
    }

    public static double MarzaDeweloperska() {
        return 1.2;
    }

    public static double KosztNaDzienKoparka() {
        return 300.0;
    }

    public static double KosztNaDzienDzwig() {
        return 500.0;
    }

    public static double KosztNaDzienBetoniarka() {
        return 100.0;
    }
}