package sprzet;

abstract public class SprzetBudowlany {
    private final String nazwa;
    private final int dziennyCzasPracy;

    public SprzetBudowlany(String nazwa, int dziennyCzasPracy) {
        this.nazwa = nazwa;
        this.dziennyCzasPracy = dziennyCzasPracy;
    }

    public void DrukujDaneSprzetu() {
        System.out.println("Sprzęt: " + nazwa);
        System.out.println("Dzienny czas pracy: " + dziennyCzasPracy + " h");
    }

    public abstract double ObliczKosztEksploatacjiDzienny();

    public void DrukujKosztEksploatacji() {
        DrukujDaneSprzetu();
        System.out.println("Dzienne koszty eksploatacji: " + ObliczKosztEksploatacjiDzienny() + " zł");
        System.out.println();
    }
}