import firma.Firma;
import kosztorysy.KosztorysBudowlany;
import parametry.Data;
import pracownicy.PracownikBudowlany;
import sprzet.Betoniarka;
import sprzet.Dzwig;
import sprzet.Koparka;
import sprzet.SprzetBudowlany;
import zlecenia.ZlecenieBudowlane;
import zlecenia.ZlecenieNaElewacje;
import zlecenia.ZlecenieNaFundamenty;

public class Main {
    public static void main(String[] args) {

        System.out.println("Typy generyczne\n");


        Firma firma = new Firma("Jagodowa Firma Budowlana");

        PracownikBudowlany pracownik1 = new PracownikBudowlany("Piotr", "Jagodzinski", "Kierownik budowy");
        PracownikBudowlany pracownik2 = new PracownikBudowlany("Anna", "Nowak", "Inżynier");

        firma.getBazaDanych().getPracownicy().dodaj(pracownik1);
        firma.getBazaDanych().getPracownicy().dodaj(pracownik2);

        Koparka koparka = new Koparka(8);
        Dzwig dzwig = new Dzwig(10);
        Betoniarka betoniarka = new Betoniarka(6);
        firma.getBazaDanych().getSprzety().dodaj(koparka);
        firma.getBazaDanych().getSprzety().dodaj(dzwig);
        firma.getBazaDanych().getSprzety().dodaj(betoniarka);

        Data dataZawarcia = new Data(10, 10, 2024);
        ZlecenieNaFundamenty zlecenieFundamenty = new ZlecenieNaFundamenty(
                "FND-001",
                pracownik1,
                dataZawarcia,
                "Fundamenty domu",
                160,
                20000.0
        );
        ZlecenieNaElewacje zlecenieElewacje = new ZlecenieNaElewacje(
                "ELEW-001",
                pracownik2,
                dataZawarcia,
                "Elewacja domu",
                150,
                5000.0,
                3000.0
        );
        firma.getBazaDanych().getZlecenia().dodaj(zlecenieFundamenty);
        firma.getBazaDanych().getZlecenia().dodaj(zlecenieElewacje);

        KosztorysBudowlany kosztorysFundamenty = new KosztorysBudowlany(zlecenieFundamenty, 5);
        kosztorysFundamenty.DodajSprzet(koparka);
        kosztorysFundamenty.DodajSprzet(dzwig);
        kosztorysFundamenty.DodajSprzet(betoniarka);

        KosztorysBudowlany kosztorysElewacje = new KosztorysBudowlany(zlecenieElewacje, 3);
        kosztorysElewacje.DodajSprzet(koparka);
        kosztorysElewacje.DodajSprzet(betoniarka);

        System.out.println("<(-.-)> KOSZTORYS FUNDAMENTY <(-.-)>");
        kosztorysFundamenty.DrukujKosztorys();
        System.out.println("\n<(-.^)> KOSZTORYS ELEWACJE <(^.-)>");
        kosztorysElewacje.DrukujKosztorys();

        System.out.println("\n<(^.-)> PRACOWNICY W FIRMIE <(-.^)>");
        for (PracownikBudowlany p : firma.getBazaDanych().getPracownicy().getLista()) {
            p.Wyswietl();
            System.out.println();
        }

        System.out.println("\n<(-.-)> ZLECENIA W FIRMIE <(-.-)>");
        for (ZlecenieBudowlane z : firma.getBazaDanych().getZlecenia().getLista()) {
            z.DrukujKosztZlecenia();
        }

        System.out.println("\n<(-.^)> SPRZĘT W FIRMIE <(^.-)>");
        for (SprzetBudowlany s : firma.getBazaDanych().getSprzety().getLista()) {
            s.DrukujKosztEksploatacji();
        }
    }
}